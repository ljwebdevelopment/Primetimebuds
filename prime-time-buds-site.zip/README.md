# Prime Time Buds (View-Only Website)

This is a modern, grounded static website for Prime Time Buds in Tahlequah, OK.
It includes a view-only inventory grid with a "View Details" modal and no purchasing.

## File structure
- index.html
- css/styles.css
- js/script.js
- assets/logo.png (replace with the real logo if needed)

## How to run locally
1. Open the folder in VS Code.
2. Use a local server (recommended) so the <dialog> works consistently:
   - VS Code extension: "Live Server"
   - Or in terminal:
     - Python: `python -m http.server 5500`
3. Open http://localhost:5500

## How to deploy on GitHub Pages
1. Create a GitHub repo (e.g., primetime-buds-site).
2. Upload all files/folders.
3. Repo Settings → Pages:
   - Source: Deploy from a branch
   - Branch: main / root
4. Save and wait for the Pages URL.

## Inventory placeholders
Edit `js/script.js` and update the `inventory` array objects. Add your real names, categories, and details.

No cart, no checkout, no pricing required.
